#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <ctime>
#include <conio.h>
#include <Windows.h>
using namespace std;

class Enigma_Files
{
public:

	void Read_file(string file_name)
	{
		ifstream file(file_name, ifstream::in);

		if (!file.good())
		{
			file.close();
			cout << file_name << " �ɮ׵L�k�}��";
			return;
		}

		for (string s; !file.eof(); )
		{
			file >> s;
			data += s;
		}

		file.close();
	}
	
	void Write_file(string file_name)
	{
		ofstream file(file_name, ifstream::out);

		if (!file.good())
		{
			file.close();
			cout << file_name << " �ɮ׵L�k�}��";
			return;
		}

		file << data;

		file.close();
	}

	void Push(char const& c)
	{
		data.push_back(c);
	}

	char const& operator [] (size_t const& i)
	{
		return data[i];
	}

	string Data()
	{
		return data;
	}

	size_t Length()
	{
		return data.length();
	}

protected:
	string data;
};

class Enigma_Component
{
public:
	Enigma_Component() :
		link(nullptr)
	{
	}

	Enigma_Component(string file) :
		link(nullptr)
	{
		Read_table(file);
	}

	char Input_signal(char owo) // owo �i�ର �r����ASCII_CODE �άO ��m (�άO�����Ÿ�?)
	{	
		return Forward(owo); //������ owo �ǹL�h�A�o�쪺�i��O �r���� ASCII_CODE �άO ��m
	}

	void Link(Enigma_Component & next)
	{
		link = &next;
	}

	virtual void Reset() = 0; //���]����

	virtual void Spin() = 0; //���ྦ��

protected:
	Enigma_Component *link;

	vector<size_t> encode_table;

	virtual size_t Forward(size_t const& i) = 0;

	void Read_table(string file_name)
	{
		ifstream file(file_name, ifstream::in);

		if (!file.good())
		{
			file.close();
			cout << file_name << " �ɮ׵L�k�}��";
			return;
		}

		for (char s; !file.eof(); )
		{
			file >> s;
			if(!file.eof())
				encode_table.push_back((size_t)s);
		}

		file.close();
	}
};