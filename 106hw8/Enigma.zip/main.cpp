#include "Enigma.h"

int main()
{
	srand((unsigned int)time(0));

	Enigma_Files Rotor_start_file;
	Enigma_Files Rotor_arrow_file;
	Enigma_Files original_message_file;
	Enigma_Files encoded_message_file;

	cout << "HW8 version" << endl << endl <<
		"Ū�J��l�r��: \"original_data.txt\"" << endl;
	original_message_file.Read_file("original_data.txt");

	cout <<
		"Ū�J��������r��: \"Rotor_start_web.txt\"" << endl;
	Rotor_start_file.Read_file("Rotor_start_web.txt");

	cout <<
		"Ū�J�������V�r��: \"Rotor_arrow_web.txt\"" << endl;
	Rotor_arrow_file.Read_file("Rotor_arrow_web.txt");

	cout << endl <<
		"Ū�J���u�O: \"Plugboard_web.txt\"" << endl;
	Plugboard plugboard("Plugboard_web.txt");

	for (size_t i = 0; i < 26; i++)
		cout << char('A' + i);
	cout << endl << plugboard << endl;

	cout << endl <<
		"Ū�J����3�]�w��: \"Rotor_III_web.txt\"" << endl;
	Rotor Rotor_III("Rotor_III_web.txt", Rotor_start_file[0], Rotor_arrow_file[0]);

	cout << Rotor_III << endl;

	cout << endl <<
		"Ū�J����2�]�w��: \"Rotor_II_web.txt\"" << endl;
	Special_Rotor Rotor_II("Rotor_II_web.txt", Rotor_start_file[1], Rotor_arrow_file[1]);

	cout << Rotor_II << endl;

	cout << endl <<
		"Ū�J����1�]�w��: \"Rotor_I_web.txt\"" << endl;
	Rotor Rotor_I("Rotor_I_web.txt", Rotor_start_file[2], Rotor_arrow_file[2]);

	cout << Rotor_I << endl;

	cout << endl <<
		"Ū�J�Ϯg��: \"Reflector_web.txt\"" << endl;
	Reflector reflector("Reflector_web.txt");

	for (size_t i = 0; i < 26; i++)
		cout << char('A' + i);
	cout << endl << reflector << endl;


	plugboard.Link(Rotor_III); //�s�����u�O�򾦽�3
	Rotor_III.Link(Rotor_II); //�s������3�򾦽�2
	Rotor_II.Link(Rotor_I); //�s������2�򾦽�1
	Rotor_I.Link(reflector); //�s������1��Ϯg��





	cout << endl << endl <<
		"��l�r��: " << endl << endl <<
		"****************************************************" << endl <<
		"*                                                  *" << endl <<
		"*  ";
	for (size_t i = 0; i < original_message_file.Data().size(); i++)
		cout << original_message_file.Data()[i];
	cout <<                                              "  *" << endl <<
		"*                                                  *" << endl <<
		"****************************************************" << endl << endl;



	for (size_t i = 0; i < original_message_file.Length(); i++)
		encoded_message_file.Push(plugboard.Input_signal(original_message_file[i]));



	cout << endl <<
		"(�g�i�ɮ� \"encoded_data.txt\")" << endl << endl;
	encoded_message_file.Write_file("encoded_data.txt");



	cout << endl <<
		"�[�K�r��: " << endl << endl <<
		"****************************************************" << endl <<
		"*                                                  *" << endl <<
		"*  ";
	for (size_t i = 0; i < encoded_message_file.Data().size(); i++)
		cout << encoded_message_file.Data()[i];
	cout <<                                              "  *" << endl <<
		"*                                                  *" << endl <<
		"****************************************************" << endl << endl;



	cout << endl <<
		"�ѱK�^�h..." << endl << endl;



	plugboard.Reset();
	


	cout << endl <<
		"�ѱK�r��: " << endl << endl <<
		"****************************************************" << endl <<
		"*                                                  *" << endl <<
		"*  ";
	for (size_t i = 0; i < encoded_message_file.Length(); i++)
		cout << plugboard.Input_signal(encoded_message_file[i]);
	cout <<                                              "  *" << endl <<
		"*                                                  *" << endl <<
		"****************************************************" << endl << endl;



	cout << 
		"�Ы����N�����}...";
	getchar();
	return EXIT_SUCCESS;
}
